package com.book.one;

public class Main {
    public static void main(String[] args) {
        new Enter().enter();//主要程序@禁止注释以及删除//程序主程序 end start


		//new Main().main();//测试图书管理系统主要窗口//程序主窗口  end

        //new See3().see3();
        //new See2().see2();//测试图书管理系统的查询书籍  end
        //new See().see();//测试图书管理系统的查询书籍  end


        //new Upd().upd();//测试图书修改界面的功能  ing
        //new Updata().updata(); //测试图书修改界面功能修改图书按钮窗口  ing
        //new Updata().win();//测试修改目标书籍内容成功的弹窗
        //new Updata().def();//测试修改目标书籍失败的弹窗
        //new UpdataDef().updatadef();//测试修改失败行为信息框  ed
        //new Del().del();//测试删除界面 ing
        //new Del().win();//测试删除成功信息窗体 ed
        //new Add().add();
        //new Add().amount();
        //h.setV();
        //new SeeBook("JTable演示");
        //new Register().register();//  ING
        //new DelUser().delUser();
    }

}
